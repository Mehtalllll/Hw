import { useState } from "react"
import { className } from "./className";

interface IinputProp{
    placeholder?: string;
    type?: React.HTMLInputTypeAttribute;
    Length?:number;
    onchangeHndler?:(_:string)=>any;
    errorbtn?:(_:boolean)=>any;
}

const input:React.FC<IinputProp>=({
    placeholder,
    type="text",
    Length=6,
    onchangeHndler,
    errorbtn,

})=>{
    const[inputValue,setinputValue]=useState<string>("")
    const[inputError,setinputError]=useState<string>("")
  
    const onChange:React.ChangeEventHandler<HTMLInputElement>=(element)=>{
        if (onchangeHndler) onchangeHndler(element.target.value)
        if(inputError  &&  errorbtn){errorbtn(true)}else if(!inputError  &&  errorbtn){errorbtn(false)}
        const value=element.target.value
        if(type=="number"|| type =="text"){
            setinputValue(value);   
            if (value.length < Length-1 ) {
                return setinputError(`${placeholder}must be at least ${Length} characters long.`);
            }else{
                setinputError("")
            }
        }
        else if(type=="email"){
            setinputValue(value);
            if (!value.includes('.')) {
                return setinputError(`${placeholder} must contain ".".`);
              }
            if (!value.includes('@')) {
                return setinputError(`${placeholder} must contain "@".`);
              }
            setinputError("")
        }else{
            setinputValue(value)
        }
   
        // console.log(placeholder ,":",element.target.value);
    }
    
    return(
        <div className="flex flex-col">
            <input 
            value={inputValue} 
            onChange={onChange} 
            type={type} placeholder={placeholder} 
            className={className(
                "w-full border-b-2 border-[#c4c4c4]  p-3 mt-10",
                !inputError? " " : " border-red-500" )}/>
            {inputError&&<p className="text-red-500 text-sm mt-2">{inputError}</p>}
        </div>
    )
}

export default input
