export default function greenButton(Props:{ text?:string ,img?:string,submit?:()=>any,status?:boolean}){
    return(
        <button onClick={Props.submit}  disabled={Props.status}  className="w-full p-3 border  bg-[#008017]  text-white  px-6 hover:bg-[#008017cf] disabled:bg-green-400">
            {Props.text}
            <img src={Props.img} alt="" className="w-7"/>
        </button>
    )
}