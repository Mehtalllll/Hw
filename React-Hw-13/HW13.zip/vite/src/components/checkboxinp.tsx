export default function checkbox (props:{Text:string}) {
    return(
        <div className="flex  flex-row gap-x-3">
        <input type="checkbox" />
        <p>{props.Text}</p>
        </div>
    )
}