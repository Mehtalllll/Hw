import Form from './components/Form'
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {

  return (
    <>
    <Form/>
    </>
  )
}

export default App
