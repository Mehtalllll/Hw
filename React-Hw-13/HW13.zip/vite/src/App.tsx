import Input from "./components/inputs";
import UploadIcon from "./components/Uploadicon.svg"
import Amrika from "./components/amka.png"
import Tick from "./components/tick.svg"
import Button from "./components/Button"
import Checkboxinp from "./components/checkboxinp";
import { className } from "./components/className";
import { useState } from "react";

export default function App() {

  const [Btn, setBtn] = useState<boolean>()

  const [Values, setValues] = useState<{
    "Your company name"?: string,
    "Nature of Bussiness"?: string,
    "Adress"?: String,
    "PostCode"?: Number,
    "Contact name"?: String,
    "Contact Phone"?: Number,
    "Mail"?: String,
    "Linkdin"?: String,
    "Lets talk about your idea"?: string,

  }>()

  const inputChangeHandler=(
    inputType: "Your company name" | "Nature of Bussiness" | "Adress" | "PostCode" | "Contact name" | "Contact Phone" | "Mail" | "Linkdin" | "Lets talk about your idea",
    Value: string
    )=>{
      setValues({...Values,[inputType]: Value})
      if(
        Values?.Adress&&
        Values["Contact Phone"]&&
        Values["Contact name"]&&
        Values["Lets talk about your idea"]&&
        Values.Linkdin&&
        Values.Mail&&
        Values["Nature of Bussiness"]&&
        Values.PostCode&&
        Values["Your company name"]
      ){
        setBtn(false)
      }
    }

    const submit=()=>{
      console.log(Values);

    }



  return (
    <div className="container mx-auto grid md:grid-cols-2 gap-x-36 px-10 mt-20 mb-48 ">
      <div className="flex flex-col gap-y-6">
        <p className="font-bold text-4xl text-[#353638]"> Contact us</p>
        <p className="font-semibold text-sm text-[#979797]">
          Need an experienced and skilled hand with custom IT project? <br />{" "}
          Fill out the from to get a free consultation{" "}
        </p>
        <div className="mt-5">
          <Input errorbtn={(status)=>{setBtn(status)}} onchangeHndler={(value)=>inputChangeHandler("Your company name",value)} placeholder="Your company name"  />
          <Input errorbtn={(status)=>{setBtn(status)}} onchangeHndler={(value)=>inputChangeHandler("Nature of Bussiness",value)} placeholder="Nature of Bussiness" />
          <div className="flex flex-row gap-x-3">
            <div className="w-4/6">
              <Input errorbtn={(status)=>{setBtn(status)}} onchangeHndler={(value)=>inputChangeHandler("Adress",value)} placeholder="Adress" Length={6} />
            </div>
            <div className="w-2/6">
              <Input errorbtn={(status)=>{setBtn(status)}} onchangeHndler={(value)=>inputChangeHandler("PostCode",value)} placeholder="PostCode" type="number" />
            </div>
          </div>
          <Input errorbtn={(status)=>{setBtn(status)}} onchangeHndler={(value)=>inputChangeHandler("Contact name",value)} placeholder="Contact name" />
          <Input errorbtn={(status)=>{setBtn(status)}} onchangeHndler={(value)=>inputChangeHandler("Contact Phone",value)} placeholder="Contact Phone" type="number" Length={11} />
          <Input errorbtn={(status)=>{setBtn(status)}} onchangeHndler={(value)=>inputChangeHandler("Mail",value)} placeholder="Mail" type="email" />
          <Input errorbtn={(status)=>{setBtn(status)}} onchangeHndler={(value)=>inputChangeHandler("Linkdin",value,)} placeholder="Linkdin" />
          <Input errorbtn={(status)=>{setBtn(status)}} onchangeHndler={(value)=>inputChangeHandler("Lets talk about your idea",value)} placeholder="Lets talk about your idea" />
          <div className={className(
            " w-full border-dashed border-2 placeholder:text-center",
            " border-[#c4c4c4]  p-10 mt-16")}>
            <div className="flex flex-row gap-x-2 justify-center cursor-pointer opacity-50">
              <img src={UploadIcon} alt="" className="w-5" />
              <p>Upload Additional File</p>
            </div>
          </div>
          <p className="mt-2 opacity-40 text-sm pb-8">Attach file.File size of your document should not exceed 10MB </p>
        </div>
        <Button text="Submit" submit={submit} status={Btn}  />
        <Checkboxinp Text="i want to product my data by singing and NDA" />
      </div>
      <div>
        <div className=" flex flex-col pt-52 gap-y-12 items-start opacity-80" >
          <p className="font-bold ">Offices</p>
          <p>United Kindom <br /> High St,Bromley BR1 1DN</p>
          <p>United States <br /> 80 Avenue des Terroirs de France, Paris</p>
          <p>France <br /> 80 Avenue des Terroirs de France, Paris</p>
        </div>
        <div className=" flex flex-col pt-20 gap-y-9 items-start opacity-80" >
          <p className="font-bold ">For Quick nquiries</p>
          <div className="flex flex-row "><img className="w-6 h-6" src={Amrika} alt="" /><p>+44 7777777777</p></div>
          <div className="flex flex-row "><img className="w-6 h-6" src={Amrika} alt="" /><p>+44 7777777777</p></div>
        </div>
        <div className=" flex flex-col pt-20 gap-y-5 items-start opacity-80" >
          <p className="font-bold ">Wold you Like to  join oure newsletters</p>
          <div className="flex flex-row justify-items-center gap-x-4">
            <Input errorbtn={(status)=>{setBtn(status)}} placeholder="Email" type="email" /><div className="flex justify-start py-[38px]"><Button img={Tick} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
