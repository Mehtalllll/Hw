import { useState } from "react";
import Humburger from "./Humburger.svg";

export default function header() {
  const [visibility,setvisibility]=useState<boolean>(true)
  let [menuitem,setmenuitem]=useState<string>("Company")
  return (
    <>
    <div className=" container mx-auto w-full bg-[#f9f9f9] flex flex-row justify-between py-6 px-10">
      <div className="font-bold text-2xl text-[#979797]">LOGO</div>
      <div className=" w-full pr-4  flex-row gap-x-4 justify-end mx-right hidden md:flex md:gap-x-6 md:pr-20 text-sm">
        <a onClick={()=>setmenuitem(menuitem = "Company")} className={`${menuitem=="Company"? 'text-slate-700  border-b-2 border-green-600 p-2':''}`} href="#Company">Company</a>
        <a onClick={()=>setmenuitem(menuitem = "Services")} className={`${menuitem=="Services"? 'text-slate-700  border-b-2 border-green-600 p-2':''}`} href="#Services">Services</a>
        <a onClick={()=>setmenuitem(menuitem = "FinTech solution")} className={`${menuitem=="FinTech solution"? 'text-slate-700  border-b-2 border-green-600 p-2':''}`} href="#FinTech solution">FinTech solution</a>
        <a onClick={()=>setmenuitem(menuitem = "Product")} className={`${menuitem=="Product"? 'text-slate-700  border-b-2 border-green-600 p-2':''}`} href="#Product">Product</a>
        <a onClick={()=>setmenuitem(menuitem = "Portfllo")} className={`${menuitem=="Portfllo"? 'text-slate-700  border-b-2 border-green-600 p-2':''}`} href="#Portfllo">Portfllo</a>
        <a onClick={()=>setmenuitem(menuitem = "Contact us")} className={`${menuitem=="Contact us"? 'text-slate-700  border-b-2 border-green-600 p-2':''}`} href="#Contact us">Contact us</a>
      </div>
      <img src={Humburger} alt="Humburger Menu" className="w-10 md:hidden hover:opacity-55" onClick={()=>setvisibility(!visibility)}/>
    </div>
      <div className= {`w-full z-50 flex flex-col gap-y-2 py-5 pl-3 pr-4 justify-start  bg-[#f9f9f9]  ${visibility?'hidden':''}`}>
        <a onClick={()=>setmenuitem(menuitem = "Company")} className={`${menuitem=="Company"? 'text-slate-900 p-3 border-b-2 border-green-500  ':''}`} href="#Company">Company</a>
        <a onClick={()=>setmenuitem(menuitem = "Services")} className={`${menuitem=="Services"? 'text-slate-900 border-b-2 border-green-500   p-3':''}`} href="#Services">Services</a>
        <a onClick={()=>setmenuitem(menuitem = "FinTech solution")} className={`${menuitem=="FinTech solution"? 'text-slate-900 border-b-2 border-green-500   p-3':''}`} href="#FinTech solution">FinTech solution</a>
        <a onClick={()=>setmenuitem(menuitem = "Product")} className={`${menuitem=="Product"? 'text-slate-900 border-b-2 border-green-500   p-3':''}`} href="#Product">Product</a>
        <a onClick={()=>setmenuitem(menuitem = "Portfllo")} className={`${menuitem=="Portfllo"? 'text-slate-900 border-b-2 border-green-500   p-3':''}`} href="#Portfllo">Portfllo</a>
        <a onClick={()=>setmenuitem(menuitem = "Contact us")} className={`${menuitem=="Contact us"? 'text-slate-900 border-b-2 border-green-500   p-3':''}`} href="#Contact us">Contact us</a>
      </div>
    </>
  );
}
